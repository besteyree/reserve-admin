import React from 'react'

const UpdateTable = () => {
  return (
    <>
    
    </>
  )
}

export default UpdateTable